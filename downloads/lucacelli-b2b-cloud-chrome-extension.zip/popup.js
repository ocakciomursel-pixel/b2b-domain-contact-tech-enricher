let latestData = {};
const tabLocalBtn = document.getElementById('tabLocalBtn');
const tabCloudBtn = document.getElementById('tabCloudBtn');
const tabVaultBtn = document.getElementById('tabVaultBtn');
const localPane = document.getElementById('localPane');
const cloudPane = document.getElementById('cloudPane');
const vaultPane = document.getElementById('vaultPane');
const apifyTokenInput = document.getElementById('apifyToken');
const cloudActorSelect = document.getElementById('cloudActor');
const bulkTargetsBox = document.getElementById('bulkTargets');

const savedToken = localStorage.getItem('lucacelli_apify_token') || '';
if (savedToken) apifyTokenInput.value = savedToken;
const defaultActor = cloudActorSelect.getAttribute('data-default');
if (defaultActor) cloudActorSelect.value = defaultActor;

function syncActorSample() {
  const opt = cloudActorSelect.options[cloudActorSelect.selectedIndex];
  const sample = opt ? opt.getAttribute('data-sample') : '';
  if (sample) bulkTargetsBox.value = sample;
}
cloudActorSelect.addEventListener('change', syncActorSample);
syncActorSample();

function switchTab(mode) {
  [tabLocalBtn, tabCloudBtn, tabVaultBtn].forEach(b => b.classList.remove('active'));
  localPane.style.display = mode === 'local' ? 'block' : 'none';
  cloudPane.style.display = mode === 'cloud' ? 'block' : 'none';
  vaultPane.style.display = mode === 'vault' ? 'block' : 'none';
  if (mode === 'local') tabLocalBtn.classList.add('active');
  if (mode === 'cloud') tabCloudBtn.classList.add('active');
  if (mode === 'vault') { tabVaultBtn.classList.add('active'); loadVault(); }
}

tabLocalBtn.addEventListener('click', () => switchTab('local'));
tabCloudBtn.addEventListener('click', () => switchTab('cloud'));
tabVaultBtn.addEventListener('click', () => switchTab('vault'));

async function saveToVault(item) {
  try {
    const data = await chrome.storage.local.get(['lucacelli_vault']);
    const vault = Array.isArray(data.lucacelli_vault) ? data.lucacelli_vault : [];
    const filtered = vault.filter(v => v.domain !== item.domain);
    filtered.unshift({
      domain: item.domain || item.url || 'unknown',
      title: item.title || '',
      emails: (item.emails || []).join('; '),
      phones: (item.phones || []).join('; '),
      spf: item.spfRecord ? 'Valid' : 'None',
      savedAt: new Date().toISOString()
    });
    await chrome.storage.local.set({ lucacelli_vault: filtered.slice(0, 500) });
    tabVaultBtn.textContent = '🗄️ Vault (' + filtered.length + ')';
  } catch (_) {}
}

async function loadVault() {
  const data = await chrome.storage.local.get(['lucacelli_vault']);
  const vault = Array.isArray(data.lucacelli_vault) ? data.lucacelli_vault : [];
  tabVaultBtn.textContent = '🗄️ Vault (' + vault.length + ')';
  latestData = vault;
  document.getElementById('vaultResults').textContent = vault.length
    ? JSON.stringify(vault, null, 2)
    : 'Your Lead Vault is empty. Scan any active tab or click "Scan All Open Tabs" to populate your CRM Vault automatically!';
}

async function analyzeActiveTab() {
  const statusEl = document.getElementById('status');
  const resultsEl = document.getElementById('results');
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id || !tab.url || !tab.url.startsWith('http')) {
      statusEl.textContent = 'Open any webpage to scan locally, or use Bulk Cloud / Scan All Tabs.';
      return;
    }
    const domain = new URL(tab.url).hostname;
    statusEl.textContent = 'Analyzing ' + domain + ' locally (0 cloud credits)...';

    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const html = document.documentElement.outerHTML;
        const lower = html.toLowerCase();
        const emails = [...new Set((html.match(/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,10}\b/g) || []).map(e => e.toLowerCase()))].slice(0, 15);
        const phones = [...new Set(html.match(/\+?[1-9][0-9\s().-]{7,16}[0-9]/g) || [])].slice(0, 8);
        const socials = [...new Set([...document.querySelectorAll('a[href]')].map(a => a.href).filter(h => /linkedin\.com|twitter\.com|x\.com|instagram\.com|youtube\.com|facebook\.com/i.test(h)))].slice(0, 12);
        return {
          engine: 'local-active-tab-free-v3',
          url: location.href,
          domain: location.hostname,
          title: document.title,
          emails,
          phones,
          socials,
          techSignals: {
            wordpress: lower.includes('wp-content'),
            shopify: lower.includes('cdn.shopify.com'),
            stripe: lower.includes('stripe.com'),
            gtm: lower.includes('googletagmanager.com'),
            metaPixel: lower.includes('connect.facebook.net'),
            hubspot: lower.includes('hubspot')
          }
        };
      }
    });

    const dnsRes = await fetch('https://dns.google/resolve?name=' + encodeURIComponent(domain) + '&type=TXT').then(r => r.json()).catch(() => ({}));
    const txts = (dnsRes.Answer || []).map(a => a.data);
    result.spfRecord = txts.find(t => String(t).toLowerCase().includes('v=spf1')) || null;

    latestData = result;
    statusEl.textContent = 'Saved ' + domain + ' to Lead Vault (0 credits used)';
    resultsEl.textContent = JSON.stringify(result, null, 2);
    await saveToVault(result);
  } catch (err) {
    statusEl.textContent = 'Error: ' + err.message;
  }
}

document.getElementById('scanAllTabsBtn').addEventListener('click', async () => {
  const statusEl = document.getElementById('status');
  const resultsEl = document.getElementById('results');
  statusEl.textContent = 'Scanning all open browser tabs locally (100% Free)...';
  const tabs = await chrome.tabs.query({ currentWindow: true });
  const batch = [];
  for (const t of tabs) {
    if (!t.url || !t.url.startsWith('http')) continue;
    try {
      const [{ result }] = await chrome.scripting.executeScript({
        target: { tabId: t.id },
        func: () => {
          const html = document.documentElement.outerHTML;
          const emails = [...new Set((html.match(/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,10}\b/g) || []).map(e => e.toLowerCase()))].slice(0, 10);
          const phones = [...new Set(html.match(/\+?[1-9][0-9\s().-]{7,16}[0-9]/g) || [])].slice(0, 5);
          return { domain: location.hostname, url: location.href, title: document.title, emails, phones };
        }
      });
      if (result) {
        batch.push(result);
        await saveToVault(result);
      }
    } catch (_) {}
  }
  latestData = batch;
  statusEl.textContent = 'Batch scanned ' + batch.length + ' open tabs & saved to Vault!';
  resultsEl.textContent = JSON.stringify(batch, null, 2);
});

document.getElementById('runCloudBtn').addEventListener('click', async () => {
  const token = apifyTokenInput.value.trim();
  const actor = cloudActorSelect.value;
  const opt = cloudActorSelect.options[cloudActorSelect.selectedIndex];
  const inputType = opt ? opt.getAttribute('data-type') : 'domains';
  const lines = bulkTargetsBox.value.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
  const outEl = document.getElementById('cloudResults');

  if (!token) {
    outEl.textContent = 'Please paste your free Apify API Token (apify_api_...). Get $5.00/mo free credit at console.apify.com/settings/integrations';
    return;
  }
  localStorage.setItem('lucacelli_apify_token', token);
  outEl.textContent = 'Running Public Apify Actor lucacelli/' + actor + ' on ' + lines.length + ' targets...';

  let payload = {};
  if (inputType === 'urls') payload = { urls: lines.map(u => u.startsWith('http') ? u : 'https://' + u) };
  else if (inputType === 'queries') payload = { queries: lines, maxResultsPerQuery: 5 };
  else if (inputType === 'usernames') payload = { usernames: lines };
  else if (inputType === 'companies') payload = { companies: lines, maxJobsPerCompany: 5 };
  else if (inputType === 'subreddits') payload = { subreddits: lines, limitPerSubreddit: 5 };
  else if (inputType === 'keywords') payload = { keywords: lines, hitsPerKeyword: 5 };
  else if (inputType === 'conditions') payload = { conditions: lines, maxTrialsPerCondition: 5 };
  else payload = { domains: lines.map(d => d.replace(/^https?:\/\//i, '').split('/')[0]) };

  try {
    const endpoint = 'https://api.apify.com/v2/acts/lucacelli~' + actor + '/run-sync-get-dataset-items?token=' + encodeURIComponent(token);
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    latestData = data;
    outEl.textContent = JSON.stringify(data, null, 2);
  } catch (err) {
    outEl.textContent = 'Cloud API Error: ' + err.message;
  }
});

document.getElementById('clearVaultBtn').addEventListener('click', async () => {
  await chrome.storage.local.set({ lucacelli_vault: [] });
  loadVault();
});

document.getElementById('copyBtn').addEventListener('click', () => {
  navigator.clipboard.writeText(JSON.stringify(latestData, null, 2));
  document.getElementById('copyBtn').textContent = 'Copied!';
  setTimeout(() => { document.getElementById('copyBtn').textContent = 'Copy JSON'; }, 1400);
});

document.getElementById('csvBtn').addEventListener('click', () => {
  const rows = Array.isArray(latestData) ? latestData : [latestData];
  if (!rows.length) return;
  const keys = Object.keys(rows[0] || {});
  const csv = [keys.join(','), ...rows.map(r => keys.map(k => JSON.stringify(r[k] ?? '')).join(','))].join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'lucacelli-b2b-export.csv';
  a.click();
});

loadVault();
analyzeActiveTab();
