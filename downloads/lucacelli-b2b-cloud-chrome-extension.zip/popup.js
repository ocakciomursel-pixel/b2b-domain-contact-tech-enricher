let latestData = {};
let activeMode = 'local';

const tabLocalBtn = document.getElementById('tabLocalBtn');
const tabCloudBtn = document.getElementById('tabCloudBtn');
const localPane = document.getElementById('localPane');
const cloudPane = document.getElementById('cloudPane');
const apifyTokenInput = document.getElementById('apifyToken');
const cloudActorSelect = document.getElementById('cloudActor');

// Load saved token & default actor
const savedToken = localStorage.getItem('lucacelli_apify_token') || '';
if (savedToken) apifyTokenInput.value = savedToken;
const defaultActor = cloudActorSelect.getAttribute('data-default');
if (defaultActor) cloudActorSelect.value = defaultActor;

apifyTokenInput.addEventListener('change', () => {
  localStorage.setItem('lucacelli_apify_token', apifyTokenInput.value.trim());
});

tabLocalBtn.addEventListener('click', () => {
  activeMode = 'local';
  tabLocalBtn.classList.add('active');
  tabCloudBtn.classList.remove('active');
  localPane.style.display = 'block';
  cloudPane.style.display = 'none';
});

tabCloudBtn.addEventListener('click', () => {
  activeMode = 'cloud';
  tabCloudBtn.classList.add('active');
  tabLocalBtn.classList.remove('active');
  cloudPane.style.display = 'block';
  localPane.style.display = 'none';
});

async function analyzeActiveTab() {
  const statusEl = document.getElementById('status');
  const resultsEl = document.getElementById('results');
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id || !tab.url || !tab.url.startsWith('http')) {
      statusEl.textContent = 'Open any http/https webpage to scan locally, or switch to Bulk Cloud tab.';
      return;
    }
    const domain = new URL(tab.url).hostname;
    statusEl.textContent = 'Analyzing ' + domain + ' locally (0 cloud credits)...';

    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const html = document.documentElement.outerHTML;
        const lower = html.toLowerCase();
        const emails = [...new Set((html.match(/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,10}\b/g) || []).map(e => e.toLowerCase()))].slice(0, 15);
        const phones = [...new Set(html.match(/\+?[1-9][0-9\s().-]{7,16}[0-9]/g) || [])].slice(0, 8);
        const socials = [...new Set([...document.querySelectorAll('a[href]')].map(a => a.href).filter(h => /linkedin\.com|twitter\.com|x\.com|instagram\.com|youtube\.com|facebook\.com/i.test(h)))].slice(0, 12);
        const missingAlt = [...document.querySelectorAll('img:not([alt]), img[alt=""]')].length;
        const navLinks = [...document.querySelectorAll('a[href]')].slice(0, 8).map(a => '- [' + (a.innerText || a.href).trim().slice(0, 40) + '](' + a.href + ')');
        return {
          engine: 'local-active-tab-free',
          url: location.href,
          domain: location.hostname,
          title: document.title,
          metaDescription: document.querySelector('meta[name="description"]')?.content || null,
          emails,
          phones,
          socials,
          adPixels: {
            googleTagManager: lower.includes('googletagmanager.com'),
            metaPixel: lower.includes('connect.facebook.net'),
            linkedInInsight: lower.includes('snap.licdn.com'),
            tiktokPixel: lower.includes('analytics.tiktok.com'),
          },
          techSignals: {
            stripe: lower.includes('stripe.com'),
            shopify: lower.includes('cdn.shopify.com'),
            hubspot: lower.includes('hubspot') || lower.includes('hs-scripts'),
            intercom: lower.includes('intercom'),
            toastPos: lower.includes('toasttab.com'),
            openTable: lower.includes('opentable.com'),
          },
          accessibility: {
            totalImages: document.querySelectorAll('img').length,
            imagesMissingAlt: missingAlt,
            hasLangAttribute: Boolean(document.documentElement.getAttribute('lang')),
          },
          llmsTxtPreview: '# ' + document.title + '\n\n' + navLinks.join('\n'),
        };
      },
    });

    const dnsRes = await fetch('https://dns.google/resolve?name=' + encodeURIComponent(domain) + '&type=TXT').then(r => r.json()).catch(() => ({}));
    const txts = (dnsRes.Answer || []).map(a => a.data);
    result.spfRecord = txts.find(t => String(t).toLowerCase().includes('v=spf1')) || null;

    latestData = result;
    statusEl.textContent = 'Local Scan Complete for ' + domain + ' (0 credits used)';
    resultsEl.textContent = JSON.stringify(result, null, 2);
  } catch (err) {
    statusEl.textContent = 'Error: ' + err.message;
  }
}

document.getElementById('runCloudBtn').addEventListener('click', async () => {
  const token = apifyTokenInput.value.trim();
  const actor = cloudActorSelect.value;
  const lines = document.getElementById('bulkDomains').value.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
  const outEl = document.getElementById('cloudResults');

  if (!token) {
    outEl.textContent = 'Please paste your free Apify API Token (apify_api_...). Get $5.00/mo free credit at console.apify.com/settings/integrations';
    return;
  }
  localStorage.setItem('lucacelli_apify_token', token);
  outEl.textContent = 'Running Apify Cloud Actor lucacelli/' + actor + ' on ' + lines.length + ' targets...';

  const urlActors = ['ai-agent-web-markdown-llms-txt-extractor', 'saas-pricing-page-tier-feature-extractor'];
  const payload = urlActors.includes(actor)
    ? { urls: lines.map(u => u.startsWith('http') ? u : 'https://' + u) }
    : { domains: lines.map(d => d.replace(/^https?:\/\//i, '').split('/')[0]) };

  try {
    const endpoint = 'https://api.apify.com/v2/acts/lucacelli~' + actor + '/run-sync-get-dataset-items?token=' + encodeURIComponent(token);
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    latestData = data;
    outEl.textContent = JSON.stringify(data, null, 2);
  } catch (err) {
    outEl.textContent = 'Cloud API Error: ' + err.message;
  }
});

document.getElementById('copyBtn').addEventListener('click', () => {
  navigator.clipboard.writeText(JSON.stringify(latestData, null, 2));
  document.getElementById('copyBtn').textContent = 'Copied!';
  setTimeout(() => { document.getElementById('copyBtn').textContent = 'Copy JSON'; }, 1400);
});

document.getElementById('csvBtn').addEventListener('click', () => {
  const rows = Array.isArray(latestData) ? latestData : [latestData];
  if (!rows.length) return;
  const keys = Object.keys(rows[0] || {});
  const csv = [
    keys.join(','),
    ...rows.map(r => keys.map(k => JSON.stringify(r[k] ?? '')).join(','))
  ].join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'lucacelli-b2b-export.csv';
  a.click();
});

analyzeActiveTab();
