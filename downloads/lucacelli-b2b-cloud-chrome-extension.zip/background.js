chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'lucacelli-enrich-domain',
    title: '⚡ Save Page to Lucacelli B2B Lead Vault',
    contexts: ['page', 'link']
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === 'lucacelli-enrich-domain' && tab && tab.url) {
    try {
      const domain = new URL(info.linkUrl || tab.url).hostname;
      const data = await chrome.storage.local.get(['lucacelli_vault']);
      const vault = Array.isArray(data.lucacelli_vault) ? data.lucacelli_vault : [];
      vault.unshift({ domain, url: info.linkUrl || tab.url, title: tab.title || domain, savedAt: new Date().toISOString() });
      await chrome.storage.local.set({ lucacelli_vault: vault.slice(0, 500) });
    } catch (_) {}
  }
});
