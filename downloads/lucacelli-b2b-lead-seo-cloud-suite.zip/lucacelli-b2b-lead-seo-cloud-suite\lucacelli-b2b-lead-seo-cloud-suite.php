<?php
/**
 * Plugin Name: Lucacelli B2B Lead Finder, Google Maps Scraper & Technical SEO Cloud Suite
 * Plugin URI: https://ocakciomursel-pixel.github.io/b2b-domain-contact-tech-enricher/plugin-demo.html
 * Description: Hybrid Dual-Engine B2B Lead Generation, Google Maps Email Extractor, Shopify Competitor Spy & 45-Point Technical SEO Suite for WordPress. Includes a built-in Local PHP Diagnostic Engine (zero API key required) + Bulk Cloud Turbo Engine powered by Apify Cloud ($5.00/month free credit included = up to 10,000 free records/month).
 * Version: 3.0.0
 * Author: Lucacelli Cloud Data Engineering
 * Author URI: https://apify.com/lucacelli
 * License: GPLv2 or later
 * Text Domain: lucacelli-cloud-suite
 */

if (!defined('ABSPATH')) {
    exit;
}

class Lucacelli_B2B_Cloud_Suite {
    public function __construct() {
        add_action('admin_menu', array($this, 'register_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('wp_ajax_lucacelli_local_scan', array($this, 'ajax_local_scan'));
    }

    public function register_admin_menu() {
        add_menu_page(
            'B2B Leads & SEO Suite',
            'B2B Leads & SEO',
            'manage_options',
            'lucacelli-b2b-suite',
            array($this, 'render_admin_dashboard'),
            'dashicons-chart-area',
            58
        );
    }

    public function register_settings() {
        register_setting('lucacelli_suite_settings', 'lucacelli_apify_token', array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => ''
        ));
    }

    /**
     * Engine 1: Local Instant PHP Diagnostic Scanner (Works 100% Free Without Any API Key)
     */
    public function ajax_local_scan() {
        check_ajax_referer('lucacelli_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        $target = isset($_POST['target']) ? esc_url_raw(wp_unslash($_POST['target'])) : '';
        if (empty($target)) {
            wp_send_json_error('Please enter a valid URL or domain.');
        }
        if (strpos($target, 'http') !== 0) {
            $target = 'https://' . $target;
        }

        $start = microtime(true);
        $response = wp_remote_get($target, array('timeout' => 15, 'sslverify' => false));
        $latency_ms = round((microtime(true) - $start) * 1000);

        if (is_wp_error($response)) {
            wp_send_json_error($response->get_error_message());
        }

        $status = wp_remote_retrieve_response_code($response);
        $html = wp_remote_retrieve_body($response);
        $host = parse_url($target, PHP_URL_HOST);

        preg_match('/<title[^>]*>(.*?)<\/title>/is', $html, $title_m);
        preg_match('/<meta[^>]+name=["\']description["\'][^>]+content=["\']([^"\']*)["\']/is', $html, $desc_m);
        preg_match_all('/[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/', $html, $email_m);

        $emails = array_values(array_unique(array_slice($email_m[0] ?? array(), 0, 10)));
        $has_schema = (stripos($html, 'application/ld+json') !== false);
        $is_wp = (stripos($html, 'wp-content') !== false);
        $is_shopify = (stripos($html, 'cdn.shopify.com') !== false);

        wp_send_json_success(array(
            'engine' => 'Local WordPress PHP Engine (Zero API Key)',
            'url' => $target,
            'domain' => $host,
            'httpStatus' => $status,
            'latencyMs' => $latency_ms,
            'title' => isset($title_m[1]) ? trim(wp_strip_all_tags($title_m[1])) : null,
            'metaDescription' => isset($desc_m[1]) ? trim($desc_m[1]) : null,
            'discoveredEmails' => $emails,
            'hasSchemaJsonLd' => $has_schema,
            'detectedCms' => $is_shopify ? 'Shopify' : ($is_wp ? 'WordPress' : 'Custom / Cloud'),
            'scannedAt' => gmdate('c')
        ));
    }

    public function render_admin_dashboard() {
        $saved_token = esc_attr(get_option('lucacelli_apify_token', ''));
        $nonce = wp_create_nonce('lucacelli_nonce');
        ?>
        <div class="wrap" style="max-width:1180px;">
            <div style="background:#0f172a;color:#fff;padding:24px 28px;border-radius:12px;margin:16px 0 24px;border:1px solid #1e293b;">
                <span style="background:#16a34a;color:#fff;padding:4px 10px;border-radius:999px;font-size:11px;font-weight:700;">HYBRID DUAL-ENGINE ARCHITECTURE • LOCAL + APIFY CLOUD ($5/MO FREE CREDIT)</span>
                <h1 style="color:#fff;margin:10px 0 6px;font-size:26px;">Lucacelli B2B Lead Finder, Google Maps &amp; Technical SEO Cloud Suite</h1>
                <p style="color:#94a3b8;margin:0;font-size:14px;">Run single-domain SEO &amp; contact scans locally using your WordPress server (Engine 1), or connect your free Apify API Token (Engine 2 — includes <strong>$5.00/month free credit = 3,333 to 10,000 free records every month</strong>) for bulk cloud extraction without risking your hosting IP.</p>
            </div>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:24px;">
                <div style="background:#fff;border:1px solid #cbd5e1;border-radius:10px;padding:20px;">
                    <h2 style="margin-top:0;">⚡ Engine 1: Local Instant Domain &amp; SEO Scanner (No API Key Needed)</h2>
                    <p style="color:#475569;font-size:13px;">Scans a single URL directly from your WordPress PHP server for emails, title/meta, HTTP latency, Schema.org JSON-LD, and CMS detection.</p>
                    <div style="display:flex;gap:8px;">
                        <input type="text" id="lc_local_url" value="https://stripe.com" class="regular-text" style="flex:1;" placeholder="https://example.com" />
                        <button type="button" class="button button-primary" onclick="lcRunLocalScan()">Run Local Scan</button>
                    </div>
                </div>

                <div style="background:#fff;border:1px solid #cbd5e1;border-radius:10px;padding:20px;">
                    <h2 style="margin-top:0;">☁️ Engine 2: Apify Cloud Bulk Turbo Configuration ($5/Mo Free Credit)</h2>
                    <form method="post" action="options.php" style="display:flex;gap:8px;align-items:center;">
                        <?php settings_fields('lucacelli_suite_settings'); ?>
                        <input type="password" name="lucacelli_apify_token" id="lc_apify_token" value="<?php echo $saved_token; ?>" class="regular-text" style="flex:1;" placeholder="Paste Apify API Token (apify_api_...)" />
                        <button type="submit" class="button button-primary">Save Token</button>
                        <a href="https://apify.com/lucacelli" target="_blank" class="button">Get Free $5/Mo Key ↗</a>
                    </form>
                    <p style="color:#16a34a;font-size:12.5px;margin:8px 0 0;font-weight:600;">✓ 100% Transparent Single-Event Pricing ($0.50–$1.50 / 1,000 records). Apify's free plan renews $5.00 credit every month automatically.</p>
                </div>
            </div>

            <div style="background:#fff;border:1px solid #cbd5e1;border-radius:10px;padding:20px;margin-bottom:24px;">
                <h2 style="margin-top:0;">🚀 Launch Bulk Cloud Extraction (14 Live Apify Cloud Actors)</h2>
                <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:12px;">
                    <select id="lc_actor_select" style="min-width:360px;" onchange="lcUpdateActorPayload()">
                        <?php foreach ([{"slug":"google-maps-scraper-places-emails-contacts-reviews","title":"Google Maps Places, Emails & Reviews Pro","price":"$1.50 / 1,000 places","freeMonthlyQuota":"3,333 places/mo free","defaultPayload":{"searchQueries":["dentist in Miami FL","medspa in Austin TX"],"maxPlacesPerQuery":20,"enrichWebsiteData":true}},{"slug":"b2b-domain-contact-tech-enricher","title":"B2B Domain Contact, Email, DNS & Tech Enricher","price":"$0.80 / 1,000 domains","freeMonthlyQuota":"6,250 domains/mo free","defaultPayload":{"domains":["stripe.com","shopify.com","hubspot.com","linear.app","vercel.com"],"crawlContactPages":true}},{"slug":"shopify-store-product-contact-spy","title":"Shopify Store Product, Pricing & Merchant Spy","price":"$0.50 / 1,000 products","freeMonthlyQuota":"10,000 products/mo free","defaultPayload":{"stores":["gymshark.com","allbirds.com"],"maxProductsPerStore":25,"extractMerchantContacts":true}},{"slug":"ai-ready-website-to-markdown-rag-crawler","title":"Website to Clean Markdown, RAG Chunks & llms.txt","price":"$0.50 / 1,000 pages","freeMonthlyQuota":"10,000 pages/mo free","defaultPayload":{"urls":["https://docs.apify.com/platform/actors","https://crawlee.dev/docs/quick-start"],"chunkSizeTokens":500}},{"slug":"seo-technical-audit-broken-link-schema-analyzer","title":"45-Point Technical SEO, Broken Link & Schema Auditor","price":"$0.80 / 1,000 pages","freeMonthlyQuota":"6,250 pages/mo free","defaultPayload":{"urls":["https://apify.com","https://stripe.com","https://shopify.com"],"checkBrokenLinks":true}},{"slug":"github-developer-recruiter-lead-enricher","title":"GitHub Developer, Stargazer & Commit Email Enricher","price":"$0.80 / 1,000 developers","freeMonthlyQuota":"6,250 devs/mo free","defaultPayload":{"repositories":["apify/crawlee","n8n-io/n8n"],"maxDevelopersPerRepo":10}},{"slug":"ats-job-board-hiring-signal-scraper","title":"Greenhouse & Lever ATS Job & Hiring Signal Scraper","price":"$0.50 / 1,000 jobs","freeMonthlyQuota":"10,000 jobs/mo free","defaultPayload":{"greenhouseBoards":["stripe","cloudflare","vercel"],"maxJobsPerCompany":25}},{"slug":"reddit-community-pain-point-trend-miner","title":"Reddit Subreddit, Buyer Intent & Pain-Point Miner","price":"$0.50 / 1,000 posts","freeMonthlyQuota":"10,000 posts/mo free","defaultPayload":{"subreddits":["SaaS","Entrepreneur","startups"],"intentKeywords":["looking for","alternative to"]}},{"slug":"wordpress-woocommerce-site-spy","title":"WordPress & WooCommerce Theme & Plugin Spy","price":"$0.80 / 1,000 sites","freeMonthlyQuota":"6,250 sites/mo free","defaultPayload":{"domains":["techcrunch.com","wordpress.org","woocommerce.com","yoast.com"]}},{"slug":"hackernews-tech-launch-lead-monitor","title":"Hacker News Launch, Show HN & Founder Monitor","price":"$0.50 / 1,000 stories","freeMonthlyQuota":"10,000 stories/mo free","defaultPayload":{"queries":["Show HN: AI","MCP"],"maxStoriesPerQuery":15}},{"slug":"sitemap-url-inventory-content-freshness-auditor","title":"XML Sitemap URL Inventory & Freshness Auditor","price":"$0.50 / 1,000 sitemaps","freeMonthlyQuota":"10,000 sitemaps/mo free","defaultPayload":{"domains":["apify.com","cloudflare.com","stripe.com"],"maxUrlsSample":25}},{"slug":"saas-pricing-page-tier-feature-extractor","title":"SaaS Pricing Page, Plan Tiers & Feature Spy","price":"$0.80 / 1,000 pages","freeMonthlyQuota":"6,250 pages/mo free","defaultPayload":{"pricingUrls":["https://apify.com/pricing","https://stripe.com/pricing","https://linear.app/pricing"]}},{"slug":"clinical-trials-fda-drug-safety-intel","title":"ClinicalTrials.gov & OpenFDA Biotech Enricher","price":"$0.80 / 1,000 trials","freeMonthlyQuota":"6,250 trials/mo free","defaultPayload":{"conditions":["oncology immunotherapy","GLP-1 obesity"],"maxStudies":15}},{"slug":"scientific-literature-citation-author-lead-miner","title":"Scientific Paper, Author Email & Lab Lead Miner","price":"$0.50 / 1,000 papers","freeMonthlyQuota":"10,000 papers/mo free","defaultPayload":{"searchQueries":["CRISPR base editing","mRNA lipid nanoparticle"],"maxPapers":15}}] as $idx => $act): ?>
                        <?php endforeach; ?>
                    </select>
                    <button type="button" class="button button-primary" onclick="lcRunCloudActor()">▶ Run Bulk Cloud Extraction</button>
                    <button type="button" class="button" onclick="lcExportCsv()">⬇️ Export Results to CSV</button>
                </div>
                <textarea id="lc_actor_payload" rows="5" style="width:100%;font-family:monospace;font-size:12px;"></textarea>
            </div>

            <div style="background:#0f172a;color:#4ade80;border-radius:10px;padding:18px;font-family:monospace;font-size:12.5px;min-height:180px;max-height:420px;overflow:auto;" id="lc_output_console">Ready. Run a Local Instant Scan (Engine 1) or Bulk Cloud Extraction (Engine 2) above.</div>
        </div>

        <script>
        const LC_ACTORS = <?php echo wp_json_encode([{"slug":"google-maps-scraper-places-emails-contacts-reviews","title":"Google Maps Places, Emails & Reviews Pro","price":"$1.50 / 1,000 places","freeMonthlyQuota":"3,333 places/mo free","defaultPayload":{"searchQueries":["dentist in Miami FL","medspa in Austin TX"],"maxPlacesPerQuery":20,"enrichWebsiteData":true}},{"slug":"b2b-domain-contact-tech-enricher","title":"B2B Domain Contact, Email, DNS & Tech Enricher","price":"$0.80 / 1,000 domains","freeMonthlyQuota":"6,250 domains/mo free","defaultPayload":{"domains":["stripe.com","shopify.com","hubspot.com","linear.app","vercel.com"],"crawlContactPages":true}},{"slug":"shopify-store-product-contact-spy","title":"Shopify Store Product, Pricing & Merchant Spy","price":"$0.50 / 1,000 products","freeMonthlyQuota":"10,000 products/mo free","defaultPayload":{"stores":["gymshark.com","allbirds.com"],"maxProductsPerStore":25,"extractMerchantContacts":true}},{"slug":"ai-ready-website-to-markdown-rag-crawler","title":"Website to Clean Markdown, RAG Chunks & llms.txt","price":"$0.50 / 1,000 pages","freeMonthlyQuota":"10,000 pages/mo free","defaultPayload":{"urls":["https://docs.apify.com/platform/actors","https://crawlee.dev/docs/quick-start"],"chunkSizeTokens":500}},{"slug":"seo-technical-audit-broken-link-schema-analyzer","title":"45-Point Technical SEO, Broken Link & Schema Auditor","price":"$0.80 / 1,000 pages","freeMonthlyQuota":"6,250 pages/mo free","defaultPayload":{"urls":["https://apify.com","https://stripe.com","https://shopify.com"],"checkBrokenLinks":true}},{"slug":"github-developer-recruiter-lead-enricher","title":"GitHub Developer, Stargazer & Commit Email Enricher","price":"$0.80 / 1,000 developers","freeMonthlyQuota":"6,250 devs/mo free","defaultPayload":{"repositories":["apify/crawlee","n8n-io/n8n"],"maxDevelopersPerRepo":10}},{"slug":"ats-job-board-hiring-signal-scraper","title":"Greenhouse & Lever ATS Job & Hiring Signal Scraper","price":"$0.50 / 1,000 jobs","freeMonthlyQuota":"10,000 jobs/mo free","defaultPayload":{"greenhouseBoards":["stripe","cloudflare","vercel"],"maxJobsPerCompany":25}},{"slug":"reddit-community-pain-point-trend-miner","title":"Reddit Subreddit, Buyer Intent & Pain-Point Miner","price":"$0.50 / 1,000 posts","freeMonthlyQuota":"10,000 posts/mo free","defaultPayload":{"subreddits":["SaaS","Entrepreneur","startups"],"intentKeywords":["looking for","alternative to"]}},{"slug":"wordpress-woocommerce-site-spy","title":"WordPress & WooCommerce Theme & Plugin Spy","price":"$0.80 / 1,000 sites","freeMonthlyQuota":"6,250 sites/mo free","defaultPayload":{"domains":["techcrunch.com","wordpress.org","woocommerce.com","yoast.com"]}},{"slug":"hackernews-tech-launch-lead-monitor","title":"Hacker News Launch, Show HN & Founder Monitor","price":"$0.50 / 1,000 stories","freeMonthlyQuota":"10,000 stories/mo free","defaultPayload":{"queries":["Show HN: AI","MCP"],"maxStoriesPerQuery":15}},{"slug":"sitemap-url-inventory-content-freshness-auditor","title":"XML Sitemap URL Inventory & Freshness Auditor","price":"$0.50 / 1,000 sitemaps","freeMonthlyQuota":"10,000 sitemaps/mo free","defaultPayload":{"domains":["apify.com","cloudflare.com","stripe.com"],"maxUrlsSample":25}},{"slug":"saas-pricing-page-tier-feature-extractor","title":"SaaS Pricing Page, Plan Tiers & Feature Spy","price":"$0.80 / 1,000 pages","freeMonthlyQuota":"6,250 pages/mo free","defaultPayload":{"pricingUrls":["https://apify.com/pricing","https://stripe.com/pricing","https://linear.app/pricing"]}},{"slug":"clinical-trials-fda-drug-safety-intel","title":"ClinicalTrials.gov & OpenFDA Biotech Enricher","price":"$0.80 / 1,000 trials","freeMonthlyQuota":"6,250 trials/mo free","defaultPayload":{"conditions":["oncology immunotherapy","GLP-1 obesity"],"maxStudies":15}},{"slug":"scientific-literature-citation-author-lead-miner","title":"Scientific Paper, Author Email & Lab Lead Miner","price":"$0.50 / 1,000 papers","freeMonthlyQuota":"10,000 papers/mo free","defaultPayload":{"searchQueries":["CRISPR base editing","mRNA lipid nanoparticle"],"maxPapers":15}}]); ?>;
        let lcLastDataset = [];

        (function initSelect() {
            const sel = document.getElementById('lc_actor_select');
            sel.innerHTML = LC_ACTORS.map((a, i) => '<option value="' + i + '">' + a.title + ' (' + a.price + ' — ' + a.freeMonthlyQuota + ')</option>').join('');
            lcUpdateActorPayload();
        })();

        function lcUpdateActorPayload() {
            const idx = document.getElementById('lc_actor_select').value || 0;
            document.getElementById('lc_actor_payload').value = JSON.stringify(LC_ACTORS[idx].defaultPayload, null, 2);
        }

        async function lcRunLocalScan() {
            const out = document.getElementById('lc_output_console');
            const target = document.getElementById('lc_local_url').value.trim();
            out.textContent = 'Running Local PHP Scan on ' + target + '...';
            const fd = new FormData();
            fd.append('action', 'lucacelli_local_scan');
            fd.append('nonce', '<?php echo esc_js($nonce); ?>');
            fd.append('target', target);
            const res = await fetch(ajaxurl, { method: 'POST', body: fd }).then(r => r.json());
            out.textContent = JSON.stringify(res, null, 2);
            if (res.data) lcLastDataset = [res.data];
        }

        async function lcRunCloudActor() {
            const out = document.getElementById('lc_output_console');
            const token = document.getElementById('lc_apify_token').value.trim();
            const idx = document.getElementById('lc_actor_select').value || 0;
            const actor = LC_ACTORS[idx];
            if (!token) {
                out.textContent = 'Please paste your free Apify API Token in Engine 2 above (Get $5.00/month free credit at https://apify.com/lucacelli/' + actor.slug + ')';
                return;
            }
            out.textContent = 'Running Apify Cloud Actor lucacelli/' + actor.slug + '...';
            try {
                const payload = JSON.parse(document.getElementById('lc_actor_payload').value);
                const url = 'https://api.apify.com/v2/acts/lucacelli~' + actor.slug + '/run-sync-get-dataset-items?token=' + encodeURIComponent(token);
                const items = await fetch(url, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                }).then(r => r.json());
                lcLastDataset = Array.isArray(items) ? items : [items];
                out.textContent = JSON.stringify(items, null, 2);
            } catch (e) {
                out.textContent = 'Error: ' + e.message;
            }
        }

        function lcExportCsv() {
            if (!lcLastDataset.length) {
                alert('Run a scan first to export CSV.');
                return;
            }
            const keys = Object.keys(lcLastDataset[0]);
            const rows = [keys.join(',')].concat(lcLastDataset.map(row => keys.map(k => JSON.stringify(row[k] ?? '')).join(',')));
            const blob = new Blob([rows.join('\n')], { type: 'text/csv' });
            const a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = 'lucacelli-b2b-export.csv';
            a.click();
        }
        </script>
        <?php
    }
}

new Lucacelli_B2B_Cloud_Suite();
