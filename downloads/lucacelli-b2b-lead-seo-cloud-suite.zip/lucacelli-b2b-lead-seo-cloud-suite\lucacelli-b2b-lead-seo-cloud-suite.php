<?php
/**
 * Plugin Name: Lucacelli B2B Lead, SEO, Tech Stack & Cloud Enricher PRO
 * Plugin URI: https://ocakciomursel-pixel.github.io/b2b-domain-contact-tech-enricher/plugin-demo.html
 * Description: 4-Engine Hybrid B2B Suite: (1) 100% Free Unlimited Local PHP Scanner, (2) Apify Cloud Bulk Turbo Mode with $5.00/Month Free Credit (14 Live Public Actors, Single-Event Transparent Pricing), (3) [lucacelli_lead_magnet] Frontend Agency Lead Capture Shortcode, and (4) WP-Cron Scheduled Competitor Monitoring + Webhook Sync.
 * Version: 2.0.0
 * Author: Lucacelli Cloud Intelligence (@lucacelli)
 * Author URI: https://apify.com/lucacelli
 * License: GPLv2 or later
 * Text Domain: lucacelli-b2b-suite
 */

if (!defined('ABSPATH')) {
    exit;
}

class Lucacelli_B2B_Cloud_Suite_V2 {

    public static function get_public_actors() {
        return array(
        'b2b-domain-contact-tech-enricher' => array('name' => 'B2B Domain Contact, Email, DNS & Tech Stack Enricher', 'price' => '$0.50 / 1,000 results', 'free' => '10,000 enriched domains / mo FREE', 'type' => 'domains', 'sample' => 'stripe.com\nshopify.com\nlinear.app'),
        'google-maps-scraper-places-emails-contacts-reviews' => array('name' => 'Google Maps Scraper: Places, Emails, Contacts & Reviews Pro', 'price' => '$1.50 / 1,000 results', 'free' => '3,333 Google Maps leads / mo FREE', 'type' => 'queries', 'sample' => 'dentists in Austin TX\nroofing contractors in Miami FL'),
        'shopify-store-product-contact-spy' => array('name' => 'Shopify Store Product, Pricing, Stock & Merchant Contact Spy', 'price' => '$0.80 / 1,000 results', 'free' => '6,250 Shopify products & stores / mo FREE', 'type' => 'domains', 'sample' => 'gymshark.com\nallbirds.com'),
        'wordpress-woocommerce-site-spy' => array('name' => 'WordPress & WooCommerce Theme, Plugin & Agency Lead Spy', 'price' => '$0.80 / 1,000 results', 'free' => '6,250 WP/WooCommerce audits / mo FREE', 'type' => 'domains', 'sample' => 'techcrunch.com\nyoast.com\nwoocommerce.com'),
        'seo-technical-audit-broken-link-schema-analyzer' => array('name' => 'Technical SEO, Broken Link, Schema.org & Security Auditor', 'price' => '$0.50 / 1,000 results', 'free' => '10,000 technical SEO audits / mo FREE', 'type' => 'urls', 'sample' => 'https://stripe.com\nhttps://cloudflare.com'),
        'ai-ready-website-to-markdown-rag-crawler' => array('name' => 'Website to Clean Markdown, Vector RAG Chunks & llms.txt', 'price' => '$0.50 / 1,000 results', 'free' => '10,000 AI Markdown pages / mo FREE', 'type' => 'urls', 'sample' => 'https://stripe.com/docs\nhttps://docs.apify.com'),
        'saas-pricing-page-tier-feature-extractor' => array('name' => 'SaaS Pricing Page, Plan Tiers & Competitor Feature Spy', 'price' => '$0.80 / 1,000 results', 'free' => '6,250 SaaS pricing pages / mo FREE', 'type' => 'urls', 'sample' => 'https://stripe.com/pricing\nhttps://linear.app/pricing'),
        'sitemap-url-inventory-content-freshness-auditor' => array('name' => 'XML Sitemap URL Inventory, SEO Freshness & Content Auditor', 'price' => '$0.50 / 1,000 results', 'free' => '10,000 sitemap audits / mo FREE', 'type' => 'domains', 'sample' => 'apify.com\ncloudflare.com'),
        'github-developer-recruiter-lead-enricher' => array('name' => 'GitHub Developer, Stargazer & Contributor Lead Enricher', 'price' => '$1.50 / 1,000 results', 'free' => '3,333 developer profiles / mo FREE', 'type' => 'usernames', 'sample' => 'sindresorhus\ntorvalds\nyyx990803'),
        'ats-job-board-hiring-signal-scraper' => array('name' => 'Greenhouse & Lever Company Job Board & Hiring Signal Scraper', 'price' => '$1.50 / 1,000 results', 'free' => '3,333 company hiring signals / mo FREE', 'type' => 'companies', 'sample' => 'stripe\ncloudflare\nfigma'),
        'reddit-community-pain-point-trend-miner' => array('name' => 'Reddit Subreddit, Buyer Intent & Pain-Point Lead Miner', 'price' => '$0.80 / 1,000 results', 'free' => '6,250 Reddit buyer-intent posts / mo FREE', 'type' => 'subreddits', 'sample' => 'SaaS\nentrepreneur\nsmallbusiness'),
        'hackernews-tech-launch-lead-monitor' => array('name' => 'Hacker News Launch, Show HN & Tech Founder Lead Monitor', 'price' => '$0.80 / 1,000 results', 'free' => '6,250 HackerNews founder leads / mo FREE', 'type' => 'keywords', 'sample' => 'Show HN\nAI agent\nopen source'),
        'scientific-literature-citation-author-lead-miner' => array('name' => 'Scientific Paper, Author Email & Lab Research Lead Miner', 'price' => '$1.50 / 1,000 results', 'free' => '3,333 academic/biotech leads / mo FREE', 'type' => 'queries', 'sample' => 'CRISPR gene editing\nmRNA lipid nanoparticle'),
        'clinical-trials-fda-drug-safety-intel' => array('name' => 'ClinicalTrials.gov & OpenFDA Biotech / Pharma Lead Enricher', 'price' => '$1.50 / 1,000 results', 'free' => '3,333 clinical trial & FDA records / mo FREE', 'type' => 'conditions', 'sample' => 'nsclc\nglioblastoma\ntype 2 diabetes')
        );
    }

    public function __construct() {
        add_action('admin_menu', array($this, 'register_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('wp_ajax_lucacelli_local_scan', array($this, 'ajax_local_scan'));
        add_action('wp_ajax_lucacelli_apify_bulk', array($this, 'ajax_apify_bulk'));
        add_action('wp_ajax_lucacelli_public_lead_magnet', array($this, 'ajax_public_lead_magnet'));
        add_action('wp_ajax_nopriv_lucacelli_public_lead_magnet', array($this, 'ajax_public_lead_magnet'));
        add_shortcode('lucacelli_lead_magnet', array($this, 'render_lead_magnet_shortcode'));
        add_action('lucacelli_daily_cloud_cron', array($this, 'run_scheduled_cloud_job'));
    }

    public function register_admin_menu() {
        add_menu_page(
            'B2B Lead & SEO Suite PRO',
            'B2B Lead & SEO PRO',
            'manage_options',
            'lucacelli-b2b-suite',
            array($this, 'render_dashboard'),
            'dashicons-chart-area',
            56
        );
    }

    public function register_settings() {
        register_setting('lucacelli_b2b_settings', 'lucacelli_apify_api_token', array('sanitize_callback' => 'sanitize_text_field'));
        register_setting('lucacelli_b2b_settings', 'lucacelli_webhook_url', array('sanitize_callback' => 'esc_url_raw'));
        register_setting('lucacelli_b2b_settings', 'lucacelli_cron_actor', array('sanitize_callback' => 'sanitize_text_field'));
        register_setting('lucacelli_b2b_settings', 'lucacelli_cron_targets', array('sanitize_callback' => 'sanitize_textarea_field'));

        if (!wp_next_scheduled('lucacelli_daily_cloud_cron')) {
            wp_schedule_event(time(), 'daily', 'lucacelli_daily_cloud_cron');
        }
    }

    public static function build_actor_payload($actor_slug, $lines) {
        $actors = self::get_public_actors();
        $type = isset($actors[$actor_slug]) ? $actors[$actor_slug]['type'] : 'domains';
        $clean_domains = array_map(function($d) {
            $d = preg_replace('#^https?://#i', '', trim($d));
            return explode('/', $d)[0];
        }, $lines);
        $clean_urls = array_map(function($u) {
            $u = trim($u);
            return (stripos($u, 'http') === 0) ? $u : 'https://' . $u;
        }, $lines);

        switch ($type) {
            case 'urls':
                return array('urls' => $clean_urls);
            case 'queries':
                return array('queries' => $lines, 'maxResultsPerQuery' => 5);
            case 'usernames':
                return array('usernames' => $lines);
            case 'companies':
                return array('companies' => $lines, 'maxJobsPerCompany' => 5);
            case 'subreddits':
                return array('subreddits' => $lines, 'limitPerSubreddit' => 5);
            case 'keywords':
                return array('keywords' => $lines, 'hitsPerKeyword' => 5);
            case 'conditions':
                return array('conditions' => $lines, 'maxTrialsPerCondition' => 5);
            default:
                return array('domains' => $clean_domains);
        }
    }

    public static function perform_local_domain_scan($raw_domain) {
        $domain = preg_replace('#^https?://#i', '', trim($raw_domain));
        $domain = explode('/', $domain)[0];
        $url = 'https://' . $domain;

        $response = wp_remote_get($url, array('timeout' => 12, 'user-agent' => 'Mozilla/5.0 (compatible; LucacelliB2BAuditor/2.0)'));
        $html = is_wp_error($response) ? '' : wp_remote_retrieve_body($response);

        preg_match_all('/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,12}/', $html, $email_matches);
        $emails = array_values(array_unique(array_filter($email_matches[0] ?? array(), function($e) {
            return !preg_match('/\.(png|jpg|jpeg|gif|svg|webp|js|css)$/i', $e);
        })));

        preg_match('/<title[^>]*>(.*?)<\/title>/is', $html, $title_match);
        $title = isset($title_match[1]) ? trim(wp_strip_all_tags($title_match[1])) : '';

        $lower = strtolower($html);
        $tech = array();
        if (strpos($lower, 'wp-content') !== false) $tech[] = 'WordPress';
        if (strpos($lower, 'woocommerce') !== false) $tech[] = 'WooCommerce';
        if (strpos($lower, 'cdn.shopify.com') !== false) $tech[] = 'Shopify';
        if (strpos($lower, 'googletagmanager.com') !== false) $tech[] = 'Google Tag Manager';
        if (strpos($lower, 'connect.facebook.net') !== false) $tech[] = 'Meta Pixel';
        if (strpos($lower, 'stripe.com') !== false) $tech[] = 'Stripe';
        if (strpos($lower, 'hubspot') !== false) $tech[] = 'HubSpot';
        if (strpos($lower, 'intercom') !== false) $tech[] = 'Intercom';

        $txt_records = @dns_get_record($domain, DNS_TXT);
        $spf = false;
        if (is_array($txt_records)) {
            foreach ($txt_records as $r) {
                if (isset($r['txt']) && stripos($r['txt'], 'v=spf1') !== false) {
                    $spf = $r['txt'];
                }
            }
        }

        $llms_res = wp_remote_head($url . '/llms.txt', array('timeout' => 5));
        $has_llms = (!is_wp_error($llms_res) && wp_remote_retrieve_response_code($llms_res) === 200);

        return array(
            'engine' => 'Engine 1: Local Instant PHP Scanner (100% Free Forever)',
            'domain' => $domain,
            'title' => $title,
            'emailsFound' => array_slice($emails, 0, 15),
            'detectedTechStack' => $tech,
            'hasSpfRecord' => (bool)$spf,
            'spfRecord' => $spf,
            'hasLlmsTxt' => $has_llms,
            'scannedAt' => current_time('mysql')
        );
    }

    private function log_scan_history($entry) {
        $history = get_option('lucacelli_scan_history', array());
        array_unshift($history, $entry);
        update_option('lucacelli_scan_history', array_slice($history, 0, 50));

        $webhook = get_option('lucacelli_webhook_url', '');
        if (!empty($webhook)) {
            wp_remote_post($webhook, array(
                'timeout' => 5,
                'blocking' => false,
                'headers' => array('Content-Type' => 'application/json'),
                'body' => wp_json_encode($entry)
            ));
        }
    }

    public function ajax_local_scan() {
        check_ajax_referer('lucacelli_nonce', 'nonce');
        $raw = sanitize_text_field($_POST['domain'] ?? '');
        if (empty($raw)) wp_send_json_error(array('message' => 'Please enter a domain.'));
        $res = self::perform_local_domain_scan($raw);
        $this->log_scan_history(array('type' => 'Local Free Scan', 'target' => $res['domain'], 'summary' => count($res['emailsFound']) . ' emails, ' . count($res['detectedTechStack']) . ' tech tags', 'time' => current_time('mysql')));
        wp_send_json_success($res);
    }

    public function ajax_apify_bulk() {
        check_ajax_referer('lucacelli_nonce', 'nonce');
        $token = trim(get_option('lucacelli_apify_api_token', ''));
        $actor = sanitize_text_field($_POST['actor'] ?? 'b2b-domain-contact-tech-enricher');
        $raw_targets = sanitize_textarea_field($_POST['targets'] ?? '');

        if (empty($token)) {
            wp_send_json_error(array('message' => 'Missing Apify API Token. Get your FREE $5.00/month token in 10 seconds at https://console.apify.com/settings/integrations'));
        }

        $lines = array_values(array_filter(array_map('trim', explode("\n", $raw_targets))));
        if (empty($lines)) wp_send_json_error(array('message' => 'Please enter at least 1 target line.'));

        $payload = self::build_actor_payload($actor, $lines);
        $endpoint = 'https://api.apify.com/v2/acts/lucacelli~' . urlencode($actor) . '/run-sync-get-dataset-items?token=' . urlencode($token);

        $response = wp_remote_post($endpoint, array(
            'timeout' => 120,
            'headers' => array('Content-Type' => 'application/json'),
            'body' => wp_json_encode($payload)
        ));

        if (is_wp_error($response)) {
            wp_send_json_error(array('message' => $response->get_error_message()));
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        $this->log_scan_history(array('type' => 'Apify Cloud (' . $actor . ')', 'target' => count($lines) . ' items', 'summary' => (is_array($body) ? count($body) : 1) . ' dataset rows returned', 'time' => current_time('mysql')));

        wp_send_json_success(array(
            'engine' => 'Engine 2: Apify Cloud Bulk Turbo ($5/mo Free Credit Active — Transparent Single-Event Pricing)',
            'actor' => 'lucacelli/' . $actor,
            'itemsCount' => is_array($body) ? count($body) : 0,
            'results' => $body
        ));
    }

    // ENGINE 3: FRONTEND LEAD-MAGNET SHORTCODE [lucacelli_lead_magnet]
    public function render_lead_magnet_shortcode($atts) {
        $atts = shortcode_atts(array(
            'title' => 'Free Instant B2B Website, SEO & Email Security Audit',
            'button' => 'Generate My Free Audit Report →'
        ), $atts);

        ob_start();
        ?>
        <div class="lucacelli-lead-magnet-box" style="background:#0f172a;color:#f8fafc;padding:24px;border-radius:14px;border:1px solid #334155;max-width:640px;margin:20px auto;font-family:system-ui,sans-serif;">
            <h3 style="margin:0 0 8px;color:#fff;font-size:20px;"><?php echo esc_html($atts['title']); ?></h3>
            <p style="margin:0 0 16px;color:#94a3b8;font-size:14px;">Enter your website domain and work email below for an instant live technical &amp; B2B readiness report.</p>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px;">
                <input type="text" id="lcm_domain" placeholder="yourdomain.com" style="padding:10px 12px;border-radius:8px;border:1px solid #475569;background:#1e293b;color:#fff;" />
                <input type="email" id="lcm_email" placeholder="you@company.com" style="padding:10px 12px;border-radius:8px;border:1px solid #475569;background:#1e293b;color:#fff;" />
            </div>
            <button type="button" id="lcm_btn" style="width:100%;padding:12px;border-radius:8px;border:none;background:linear-gradient(135deg,#10b981,#059669);color:#052e16;font-weight:800;cursor:pointer;"><?php echo esc_html($atts['button']); ?></button>
            <pre id="lcm_output" style="display:none;margin-top:14px;background:#020617;padding:12px;border-radius:8px;color:#34d399;font-size:12px;overflow:auto;max-height:260px;"></pre>
        </div>
        <script>
        (function(){
            const btn = document.getElementById('lcm_btn');
            if(!btn) return;
            btn.addEventListener('click', function(){
                const d = document.getElementById('lcm_domain').value.trim();
                const e = document.getElementById('lcm_email').value.trim();
                const out = document.getElementById('lcm_output');
                if(!d || !e){ alert('Please enter both your domain and email address.'); return; }
                out.style.display = 'block';
                out.textContent = 'Running live audit on ' + d + '...';
                const fd = new URLSearchParams();
                fd.append('action', 'lucacelli_public_lead_magnet');
                fd.append('domain', d);
                fd.append('email', e);
                fetch('<?php echo esc_url(admin_url('admin-ajax.php')); ?>', { method:'POST', body:fd })
                    .then(r => r.json())
                    .then(res => { out.textContent = JSON.stringify(res.data || res, null, 2); })
                    .catch(err => { out.textContent = 'Error: ' + err.message; });
            });
        })();
        </script>
        <?php
        return ob_get_clean();
    }

    public function ajax_public_lead_magnet() {
        $domain = sanitize_text_field($_POST['domain'] ?? '');
        $email = sanitize_email($_POST['email'] ?? '');
        if (empty($domain) || empty($email)) {
            wp_send_json_error(array('message' => 'Both domain and valid email are required.'));
        }
        $scan = self::perform_local_domain_scan($domain);
        $leads = get_option('lucacelli_captured_leads', array());
        array_unshift($leads, array(
            'email' => $email,
            'domain' => $scan['domain'],
            'tech' => implode(', ', $scan['detectedTechStack']),
            'spf' => $scan['hasSpfRecord'] ? 'Valid' : 'Missing',
            'time' => current_time('mysql')
        ));
        update_option('lucacelli_captured_leads', array_slice($leads, 0, 200));
        $this->log_scan_history(array('type' => 'Frontend Lead Magnet', 'target' => $email . ' (' . $scan['domain'] . ')', 'summary' => 'Captured B2B Lead', 'time' => current_time('mysql')));
        wp_send_json_success($scan);
    }

    // ENGINE 4: WP-CRON AUTOMATED SCHEDULED CLOUD MONITOR
    public function run_scheduled_cloud_job() {
        $token = trim(get_option('lucacelli_apify_api_token', ''));
        $actor = trim(get_option('lucacelli_cron_actor', ''));
        $targets = trim(get_option('lucacelli_cron_targets', ''));
        if (empty($token) || empty($actor) || empty($targets)) return;

        $lines = array_values(array_filter(array_map('trim', explode("\n", $targets))));
        if (empty($lines)) return;

        $payload = self::build_actor_payload($actor, $lines);
        $endpoint = 'https://api.apify.com/v2/acts/lucacelli~' . urlencode($actor) . '/run-sync-get-dataset-items?token=' . urlencode($token);
        $res = wp_remote_post($endpoint, array(
            'timeout' => 120,
            'headers' => array('Content-Type' => 'application/json'),
            'body' => wp_json_encode($payload)
        ));
        if (!is_wp_error($res)) {
            $body = json_decode(wp_remote_retrieve_body($res), true);
            $this->log_scan_history(array('type' => 'WP-Cron Scheduled (' . $actor . ')', 'target' => count($lines) . ' scheduled targets', 'summary' => (is_array($body) ? count($body) : 0) . ' items synced', 'time' => current_time('mysql')));
        }
    }

    public function render_dashboard() {
        $token = esc_attr(get_option('lucacelli_apify_api_token', ''));
        $webhook = esc_attr(get_option('lucacelli_webhook_url', ''));
        $cron_actor = esc_attr(get_option('lucacelli_cron_actor', 'saas-pricing-page-tier-feature-extractor'));
        $cron_targets = esc_textarea(get_option('lucacelli_cron_targets', "https://stripe.com/pricing
https://linear.app/pricing"));
        $nonce = wp_create_nonce('lucacelli_nonce');
        $actors = self::get_public_actors();
        $leads = get_option('lucacelli_captured_leads', array());
        $history = get_option('lucacelli_scan_history', array());
        ?>
        <div class="wrap" style="max-width:1180px;">
            <h1 style="display:flex;align-items:center;gap:12px;">
                <span>⚡ Lucacelli B2B Lead, SEO &amp; Cloud Intelligence Suite PRO (v2.0)</span>
                <span style="background:#10b981;color:#052e16;font-size:12px;font-weight:800;padding:4px 10px;border-radius:999px;">4-ENGINE HYBRID EDITION</span>
            </h1>

            <div style="background:linear-gradient(135deg,#0f172a,#1e293b);color:#f8fafc;padding:20px 24px;border-radius:12px;margin:16px 0;border:1px solid #334155;">
                <h2 style="color:#34d399;margin-top:0;">🎁 Includes $5.00/Month FREE Apify Cloud Credit + Unlimited Local Engine + Lead-Magnet Shortcode</h2>
                <p style="font-size:14px;color:#cbd5e1;margin-bottom:8px;">
                    <strong>Engine 1 (Local Instant Scanner):</strong> Runs 100% free &amp; unlimited on your WordPress server with zero API keys.<br/>
                    <strong>Engine 2 (Apify Cloud Bulk Turbo):</strong> Connect your free Apify account (<a href="https://console.apify.com/settings/integrations" target="_blank" style="color:#38bdf8;font-weight:700;">Get Free $5/Mo Token ↗</a>) to unlock <strong>14 Live Public Cloud Actors</strong> with 100% transparent single-event pricing ($0.50–$1.50/1k).<br/>
                    <strong>Engine 3 (Frontend Lead-Magnet Shortcode):</strong> Place <code>[lucacelli_lead_magnet]</code> on any page to capture visitor emails &amp; run instant audits!<br/>
                    <strong>Engine 4 (WP-Cron Scheduled Monitor + Webhook):</strong> Automatically monitor competitor pricing, Shopify stores, or Google Maps daily.
                </p>
            </div>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-top:18px;">
                <!-- ENGINE 1 -->
                <div style="background:#fff;border:1px solid #cbd5e1;border-radius:12px;padding:20px;">
                    <h2 style="margin-top:0;">🟢 Engine 1: Local Instant Domain Scanner (Free Forever)</h2>
                    <input type="text" id="lc_local_domain" value="stripe.com" style="width:100%;padding:10px;margin-bottom:10px;" />
                    <button type="button" class="button button-primary" id="lc_btn_local">Run Free Local Scan →</button>
                </div>

                <!-- ENGINE 2 -->
                <div style="background:#fff;border:2px solid #10b981;border-radius:12px;padding:20px;">
                    <h2 style="margin-top:0;">🚀 Engine 2: Apify Cloud Bulk Turbo (14 Public Actors)</h2>
                    <label style="font-weight:700;display:block;margin-bottom:4px;">Select Live Public Cloud Actor (@lucacelli):</label>
                    <select id="lc_cloud_actor" style="width:100%;margin-bottom:10px;">
                        <?php foreach ($actors as $slug => $meta): ?>
                            <option value="<?php echo esc_attr($slug); ?>" data-sample="<?php echo esc_attr($meta['sample']); ?>">
                                <?php echo esc_html($meta['name'] . ' (' . $meta['price'] . ' — ' . $meta['free'] . ')'); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <label style="font-weight:700;display:block;margin-bottom:4px;">Bulk Targets (One per line):</label>
                    <textarea id="lc_bulk_targets" rows="4" style="width:100%;margin-bottom:10px;font-family:monospace;">stripe.com&#10;shopify.com&#10;linear.app</textarea>
                    <button type="button" class="button button-primary" id="lc_btn_cloud" style="background:#059669;border-color:#047857;">☁️ Run Bulk Cloud Extraction ($5/Mo Free Credit) →</button>
                </div>
            </div>

            <div style="background:#0f172a;color:#e2e8f0;border-radius:12px;padding:18px;margin-top:20px;">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
                    <strong style="color:#38bdf8;">Live Extraction Output Console (JSON / CSV Ready)</strong>
                    <button type="button" class="button" id="lc_btn_csv">⬇️ Export Results to CSV</button>
                </div>
                <pre id="lc_output" style="background:#020617;color:#34d399;padding:14px;border-radius:8px;max-height:340px;overflow:auto;font-size:12px;margin:0;">Ready. Run Engine 1 (Local Free) or Engine 2 (Apify Cloud Bulk) above.</pre>
            </div>

            <!-- ENGINE 3 & 4 SETTINGS -->
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-top:20px;">
                <div style="background:#fff;border:1px solid #cbd5e1;border-radius:12px;padding:20px;">
                    <h3 style="margin-top:0;">🔑 Cloud API Key, WP-Cron Monitor &amp; Webhook Settings</h3>
                    <form method="post" action="options.php">
                        <?php settings_fields('lucacelli_b2b_settings'); ?>
                        <p>
                            <label><strong>Apify API Token (Includes $5/Mo Free Credit):</strong></label><br/>
                            <input type="password" name="lucacelli_apify_api_token" value="<?php echo $token; ?>" placeholder="apify_api_..." style="width:100%;" />
                        </p>
                        <p>
                            <label><strong>Webhook URL (Optional — Auto-POST results to n8n / Make / Slack):</strong></label><br/>
                            <input type="url" name="lucacelli_webhook_url" value="<?php echo $webhook; ?>" placeholder="https://your-n8n-or-make-webhook.com/..." style="width:100%;" />
                        </p>
                        <p>
                            <label><strong>Daily WP-Cron Scheduled Actor:</strong></label><br/>
                            <input type="text" name="lucacelli_cron_actor" value="<?php echo $cron_actor; ?>" style="width:100%;" />
                        </p>
                        <p>
                            <label><strong>Daily WP-Cron Targets (One per line):</strong></label><br/>
                            <textarea name="lucacelli_cron_targets" rows="3" style="width:100%;font-family:monospace;"><?php echo $cron_targets; ?></textarea>
                        </p>
                        <?php submit_button('Save Cloud, Cron & Webhook Settings'); ?>
                    </form>
                </div>

                <div style="background:#fff;border:1px solid #cbd5e1;border-radius:12px;padding:20px;">
                    <h3 style="margin-top:0;">🧲 Captured Frontend Leads (<code>[lucacelli_lead_magnet]</code>)</h3>
                    <p style="color:#64748b;font-size:12px;">Add shortcode <code>[lucacelli_lead_magnet]</code> to any page/post to capture visitor emails with an instant domain audit.</p>
                    <div style="max-height:150px;overflow:auto;border:1px solid #e2e8f0;border-radius:6px;margin-bottom:14px;">
                        <table class="widefat striped" style="font-size:12px;">
                            <thead><tr><th>Email</th><th>Domain</th><th>Tech</th><th>SPF</th><th>Date</th></tr></thead>
                            <tbody>
                                <?php if (empty($leads)): ?>
                                    <tr><td colspan="5">No leads captured yet. Embed <code>[lucacelli_lead_magnet]</code> on a page!</td></tr>
                                <?php else: foreach (array_slice($leads, 0, 10) as $l): ?>
                                    <tr>
                                        <td><strong><?php echo esc_html($l['email']); ?></strong></td>
                                        <td><?php echo esc_html($l['domain']); ?></td>
                                        <td><?php echo esc_html($l['tech']); ?></td>
                                        <td><?php echo esc_html($l['spf']); ?></td>
                                        <td><?php echo esc_html($l['time']); ?></td>
                                    </tr>
                                <?php endforeach; endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <h3 style="margin-top:10px;">📜 Recent Scan History (Last 10)</h3>
                    <div style="max-height:140px;overflow:auto;border:1px solid #e2e8f0;border-radius:6px;">
                        <table class="widefat striped" style="font-size:12px;">
                            <thead><tr><th>Engine</th><th>Target</th><th>Summary</th><th>Time</th></tr></thead>
                            <tbody>
                                <?php if (empty($history)): ?>
                                    <tr><td colspan="4">No scans run yet.</td></tr>
                                <?php else: foreach (array_slice($history, 0, 10) as $h): ?>
                                    <tr>
                                        <td><?php echo esc_html($h['type']); ?></td>
                                        <td><?php echo esc_html($h['target']); ?></td>
                                        <td><?php echo esc_html($h['summary']); ?></td>
                                        <td><?php echo esc_html($h['time']); ?></td>
                                    </tr>
                                <?php endforeach; endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <script>
        (function(){
            let lastData = [];
            const out = document.getElementById('lc_output');
            const actorSel = document.getElementById('lc_cloud_actor');
            const targetsBox = document.getElementById('lc_bulk_targets');

            actorSel.addEventListener('change', function(){
                const opt = actorSel.options[actorSel.selectedIndex];
                const sample = opt.getAttribute('data-sample') || '';
                if (sample) targetsBox.value = sample.replace(/\\n/g, '\n');
            });

            document.getElementById('lc_btn_local').addEventListener('click', async function(){
                const domain = document.getElementById('lc_local_domain').value;
                out.textContent = 'Scanning ' + domain + ' locally via Engine 1 (0 cloud credits)...';
                const fd = new URLSearchParams({ action: 'lucacelli_local_scan', nonce: '<?php echo $nonce; ?>', domain });
                const r = await fetch(ajaxurl, { method: 'POST', body: fd }).then(res => res.json());
                lastData = r.data ? [r.data] : [];
                out.textContent = JSON.stringify(r, null, 2);
            });

            document.getElementById('lc_btn_cloud').addEventListener('click', async function(){
                const actor = actorSel.value;
                const targets = targetsBox.value;
                out.textContent = 'Running Apify Cloud Bulk Actor (lucacelli/' + actor + ') via Engine 2...';
                const fd = new URLSearchParams({ action: 'lucacelli_apify_bulk', nonce: '<?php echo $nonce; ?>', actor, targets });
                const r = await fetch(ajaxurl, { method: 'POST', body: fd }).then(res => res.json());
                lastData = (r.data && Array.isArray(r.data.results)) ? r.data.results : [r];
                out.textContent = JSON.stringify(r, null, 2);
            });

            document.getElementById('lc_btn_csv').addEventListener('click', function(){
                if (!lastData || !lastData.length) { alert('Run a Local or Cloud scan first.'); return; }
                const rows = Array.isArray(lastData) ? lastData : [lastData];
                const keys = Object.keys(rows[0] || {});
                const csv = [keys.join(','), ...rows.map(row => keys.map(k => JSON.stringify(row[k] ?? '')).join(','))].join('\n');
                const blob = new Blob([csv], { type: 'text/csv' });
                const a = document.createElement('a');
                a.href = URL.createObjectURL(blob);
                a.download = 'lucacelli-b2b-leads.csv';
                a.click();
            });
        })();
        </script>
        <?php
    }
}

new Lucacelli_B2B_Cloud_Suite_V2();
