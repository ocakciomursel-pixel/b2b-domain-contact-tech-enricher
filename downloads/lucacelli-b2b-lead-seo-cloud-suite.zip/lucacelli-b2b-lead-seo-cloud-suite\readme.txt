=== Lucacelli B2B Lead Finder, Google Maps Scraper & Technical SEO Cloud Suite ===
Contributors: lucacelli
Tags: b2b leads, google maps scraper, seo audit, shopify spy, email finder
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 3.0.0
License: GPLv2 or later

Hybrid Dual-Engine B2B Lead Generation, Google Maps Email Extractor, Shopify Spy & 45-Point Technical SEO Suite for WordPress.

== Description ==

**Lucacelli B2B Lead & SEO Cloud Suite** combines two engines in one lightweight WordPress plugin:

1. **Engine 1 — Built-In Local PHP Diagnostic Scanner (Zero API Key Required):**
   Scan individual URLs directly from your WordPress admin panel for emails, meta tags, HTTP response latency, Schema.org JSON-LD presence, and CMS signatures without any external API key.
2. **Engine 2 — Apify Cloud Bulk Extraction Engine ($5.00/Month Free Credit Included):**
   Connect your free Apify API key to unlock 14 high-concurrency cloud scrapers on Apify Store (`@lucacelli`). Every free Apify account includes **$5.00 in free monthly credit** (automatically renewed every month), giving you:
   - Up to **3,333 Google Maps Businesses + Emails/mo FREE** ($1.50 / 1,000 places)
   - Up to **6,250 B2B Company Domains + Tech Stack/mo FREE** ($0.80 / 1,000 domains)
   - Up to **10,000 Shopify Products, ATS Jobs, or RAG Markdown Pages/mo FREE** ($0.50 / 1,000 items)
